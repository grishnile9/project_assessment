package com.stackroute.springdatajpamysql.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.springdatajpamysql.entity.Product;
import com.stackroute.springdatajpamysql.service.ProductService;

@RestController
public class ProductController {
    // Add controllers here for CRUD operations on Product entity.
	private ProductService productService;
	
	public ProductController(ProductService productService) {
		this.productService=productService;
	}
	
	@GetMapping("/products")
	public ResponseEntity<List<Product>>getAllProducts(){
		List<Product>product=productService.getAllProducts();
		return ResponseEntity.ok().body(product);
	}
	
	@GetMapping("product/{productId}")
	public ResponseEntity<Product>getProductById(@PathVariable("productId")Long productId){
		Product products = productService.getProductById(productId);
		return ResponseEntity.ok().body(products);
	}
	
	@PostMapping("/product")
	public ResponseEntity<Product> saveProduct(@RequestBody Product product){
		Product prod = productService.saveProduct(product);
		if(prod!=null) {
			return new ResponseEntity<>(prod,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PutMapping("/product")
	public ResponseEntity<Product> updateProduct(@RequestBody Product product,@PathVariable Long productId){
Product product1=productService.updateProduct(product,productId);
if(product1!=null) {
	return new ResponseEntity<>(product1,HttpStatus.OK);
}
else {
	return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
}
	}
	@DeleteMapping("/product/{productId}")
	public ResponseEntity<String>deleteProduct(@PathVariable Long productId){
		String product=productService.deleteProduct(productId);
		if(product!=null) {
			return ResponseEntity.ok().body("Product Deleted");
		}
		else {
			return ResponseEntity.notFound().build();
		}
	}
	


}
