package com.stackroute.springdatajpamysql.entity;

import jakarta.persistence.Entity;

@Entity
public class Product {
    //Add Product entity fields, constructors and getters/setters here
	
	private Long productCapacity;
	private String productName;
	private Double productprice;
	
	public Product(Long productCapacity, String productName, Double productprice) {
	
		this.productCapacity = productCapacity;
		this.productName = productName;
		this.productprice = productprice;
	}
	public Product() {
		
	}
	public Long getProductCapacity() {
		return productCapacity;
	}
	public void setProductCapacity(Long productCapacity) {
		this.productCapacity = productCapacity;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Double getProductprice() {
		return productprice;
	}
	public void setProductprice(Double productprice) {
		this.productprice = productprice;
	}
	
	
	

}
