package com.stackroute.springdatajpamysql.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stackroute.springdatajpamysql.entity.Product;

//Create ProductRepo interface extending JpaRepository
@Repository
public interface ProductRepo extends JpaRepository<Product,Long>{
}
