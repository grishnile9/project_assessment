package com.stackroute.springdatajpamysql.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.springdatajpamysql.entity.Product;
import com.stackroute.springdatajpamysql.repository.ProductRepo;

//Implement ProductService here
@Service
public class ProductServiceImpl implements ProductService  {
    //Override all the methods here
	private ProductRepo productRepo;
	
	@Autowired
	public ProductServiceImpl(ProductRepo productRepo) {
		this.productRepo = productRepo;
	}
	
	@Override
	public List<Product> getAllProducts(){
		return(List<Product>)productRepo.findAll();
	}
	
	@Override
	public Product getProductById(Long id) {
		return productRepo.findById(id).orElse(null);
	}
	
	@Override
	public Product saveProduct(Product product) {
		return productRepo.save(product);
	}
	
	public Product updateProduct(Product product,Long id) {
		Product product1 = productRepo.findById(id).orElse(null);
		if(product1 !=null) {
			product1.setProductCapacity(product.getProductCapacity());
			product1.setProductName(product.getProductName());
			product1.setProductprice(product.getProductprice());
			
			return productRepo.save(product1);
		}
		return null;
	}
	
	public String deleteProduct(Long id) {
		productRepo.deleteById(id);
		return "Product Deleted";
		
	}
}
