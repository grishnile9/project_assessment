package com.stackroute.springdatajpamysql.service;

import java.util.List;

import com.stackroute.springdatajpamysql.entity.Product;

//Create service interface here
public interface ProductService {
    //Add abstract methods here
	List<Product> getAllProducts();
	Product getProductById(Long id);
	Product saveProduct(Product product);
	Product updateProduct(Product product,Long id);
	public String deleteProduct(Long id);
}
